def pearson(x,y):
    return x+y



def main():
    x=5
    y=6
    z= pearson(x,y)
    print (z)



if __name__ == "__main__":
    main()
